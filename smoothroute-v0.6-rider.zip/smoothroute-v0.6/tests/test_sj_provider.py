from smoothroute.providers.sj_pci import fetch_sj_pci


class Response:
    def raise_for_status(self): pass
    def json(self):
        return {"features": [{"attributes": {
            "OBJECTID": 7, "STREETNAME": "ALMADEN BLVD", "STREETFROM": "A", "STREETTO": "B",
            "PCICURRENT": 87, "PCIDATE": 1760000000000, "LASTUPDATE": 1761000000000,
        }}], "exceededTransferLimit": False}


class Client:
    def get(self, *args, **kwargs): return Response()


def test_sj_provider_is_pinned_and_parses_current_pci():
    rows = fetch_sj_pci(client=Client())
    assert rows[0].segment_id == "sj:7"
    assert rows[0].pavement_score == 87.0
