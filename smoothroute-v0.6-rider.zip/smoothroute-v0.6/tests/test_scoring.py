from smoothroute.models import RoadQuality
from smoothroute.scoring import smooth_score


def test_good_road_scores_above_neutral():
    q = RoadQuality("x", pavement_score=90, sensor_score=90, defect_score=95, construction_score=100, confidence=95)
    assert smooth_score(q) > 80


def test_missing_data_is_neutral():
    assert smooth_score(RoadQuality("x")) == 50.0
