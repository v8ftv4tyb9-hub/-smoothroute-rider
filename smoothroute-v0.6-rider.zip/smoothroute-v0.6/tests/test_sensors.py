from datetime import datetime, timezone
from pathlib import Path
from smoothroute.sensors import SensorSample, SensorStore, analyze_samples


def sample(trip_id, i, a):
    return SensorSample(
        trip_id=trip_id,
        captured_at=datetime(2026,1,1,0,0,i,tzinfo=timezone.utc),
        lat=37.5+i*0.00001,
        lon=-122.2,
        accuracy_m=5,
        speed_mps=25,
        ax=a, ay=0, az=0,
    )


def test_sensor_store_roundtrip(tmp_path: Path):
    store=SensorStore(tmp_path/'sensor.db')
    t=store.start_trip(vehicle_label='test car')
    trip=t['trip_id']
    assert store.add_samples(trip,[sample(trip,0,0.4),sample(trip,1,0.6)]) == 2
    rows=store.trip_samples(trip)
    assert len(rows)==2
    assert rows[0].lat == 37.5
    store.finish_trip(trip)
    assert store.trip_meta(trip)['ended_at'] is not None


def test_analysis_detects_impacts():
    trip='t'
    smooth=[sample(trip,i,0.5) for i in range(10)]
    rough=[sample(trip,i,0.5 if i<7 else 6.0) for i in range(10)]
    a=analyze_samples(smooth)
    b=analyze_samples(rough)
    assert a['impact_count']==0
    assert b['impact_count']==3
    assert b['sensor_score'] < a['sensor_score']


def test_map_match_hook_leaves_far_sample_unmatched():
    from smoothroute.models import PciSegment
    from smoothroute.sensors import match_samples_to_pci_segments
    seg=PciSegment('SF','seg1','TEST',80,((-122.2,37.5),(-122.2,37.51)))
    near=sample('t',0,0.5)
    far=SensorSample('t',datetime(2026,1,1,tzinfo=timezone.utc),38.5,-121.0,5,20,0.5,0,0)
    matches=match_samples_to_pci_segments([near,far],[seg])
    assert matches[0]['segment_id']=='seg1'
    assert matches[1]['segment_id'] is None


def test_windows_split_by_distance_and_score():
    trip='w'
    rows=[]
    # About 11.1 m latitude spacing; enough points to cross 150 m windows.
    for i in range(40):
        rows.append(SensorSample(
            trip_id=trip,
            captured_at=datetime(2026,1,1,0,0,0,tzinfo=timezone.utc),
            lat=37.5+i*0.0001,
            lon=-122.2,
            accuracy_m=5,
            speed_mps=20,
            ax=0.5 if i < 20 else 3.0,
            ay=0,
            az=0,
        ))
    from smoothroute.sensors import aggregate_trip_windows
    windows=aggregate_trip_windows(rows, window_m=150)
    assert len(windows) >= 3
    assert windows[0]['center_lat'] < windows[-1]['center_lat']
    scored=[w for w in windows if w['sensor_score'] is not None]
    assert scored[0]['sensor_score'] > scored[-1]['sensor_score']


def test_quality_filter_rejects_bad_gps_and_low_speed():
    good=SensorSample('q',datetime(2026,1,1,tzinfo=timezone.utc),37.5,-122.2,5,20,0.5,0,0)
    badgps=SensorSample('q',datetime(2026,1,1,tzinfo=timezone.utc),37.5,-122.2,80,20,0.5,0,0)
    slow=SensorSample('q',datetime(2026,1,1,tzinfo=timezone.utc),37.5,-122.2,5,1,0.5,0,0)
    a=analyze_samples([good,badgps,slow])
    assert a['usable_sample_count']==1
    assert a['rejected']['gps']==1
    assert a['rejected']['low_speed']==1
