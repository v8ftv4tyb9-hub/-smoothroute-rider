from smoothroute.models import PciSegment, ConstructionZone
from smoothroute.providers.osrm import RouteCandidate, RouteStep
from smoothroute.spatial import route_windows, match_windows_to_pci
from smoothroute.live_routing import candidate_quality_spatial, select_routes


def test_route_windows_split_geometry():
    coords=[[-122.42,37.77],[-122.42,37.775]]
    windows=route_windows(coords,150)
    assert len(windows) >= 3
    assert 100 < windows[0]["length_m"] <= 150.1


def test_exact_segment_matching_uses_nearest_geometry_not_street_average():
    route=[[-122.4200,37.7700],[-122.4200,37.7740]]
    bad=PciSegment("sf","sf:1","Mission St",30,((-122.4200,37.7698),(-122.4200,37.7720)))
    good=PciSegment("sf","sf:2","Mission St",95,((-122.4200,37.7720),(-122.4200,37.7742)))
    matches=match_windows_to_pci(route,[bad,good],window_m=100,max_distance_m=50)
    pcis=[w["pci"] for w in matches if w["pci"] is not None]
    assert 30 in pcis and 95 in pcis


def test_spatial_quality_and_construction_penalty_change_choice():
    fast=RouteCandidate(10000,600,{"type":"LineString","coordinates":[[-122.42,37.77],[-122.42,37.80]]},(RouteStep("A",10000,600),))
    alt=RouteCandidate(11000,660,{"type":"LineString","coordinates":[[-122.40,37.77],[-122.40,37.80]]},(RouteStep("B",11000,660),))
    segments=[
        PciSegment("x","a","A",45,((-122.42,37.769),(-122.42,37.801))),
        PciSegment("x","b","B",95,((-122.40,37.769),(-122.40,37.801))),
    ]
    zones=[ConstructionZone("z",((-122.42,37.77),(-122.42,37.80)),1.0,"active work")]
    routes=select_routes([fast,alt],pci_segments=segments,construction_zones=zones)
    assert routes["fastest"]["travel_minutes"] == 10.0
    assert routes["smoothest"]["travel_minutes"] == 11.0
    assert routes["smoothest"]["smooth_score"] > routes["fastest"]["smooth_score"]
    assert routes["fastest"]["construction_fraction"] > 0.9
