from smoothroute.demo_graph import peninsula_demo_graph
from smoothroute.models import FASTEST, SMOOTHEST
from smoothroute.routing import route, summarize


def test_preferences_can_choose_different_routes():
    g = peninsula_demo_graph()
    fastest = route(g, "SF", "SJ", FASTEST)
    smoothest = route(g, "SF", "SJ", SMOOTHEST)
    assert fastest != smoothest
    assert summarize(g, smoothest)["smooth_score"] > summarize(g, fastest)["smooth_score"]
