import networkx as nx
from smoothroute.models import BALANCED
from smoothroute.profiles import get_vehicle_profile, MOTORCYCLE, SCOOTER
from smoothroute.routing import edge_cost, route


def test_two_wheel_profiles_are_more_hazard_sensitive_than_car():
    edge={"travel_minutes":10,"smooth_score":80,"pothole_risk":60,"groove_risk":70,"seam_risk":50,"metal_plate_risk":40}
    car=edge_cost(edge,BALANCED,"car")
    moto=edge_cost(edge,BALANCED,"motorcycle")
    scooter=edge_cost(edge,BALANCED,"scooter")
    assert moto > car
    assert scooter > car
    assert get_vehicle_profile("motorcycle") == MOTORCYCLE
    assert get_vehicle_profile("scooter") == SCOOTER


def test_motorcycle_can_choose_smoother_hazard_avoiding_route():
    g=nx.DiGraph()
    g.add_edge("A","B",travel_minutes=5,smooth_score=78,pothole_risk=80,groove_risk=70)
    g.add_edge("B","D",travel_minutes=5,smooth_score=78,pothole_risk=80,groove_risk=70)
    g.add_edge("A","C",travel_minutes=6,smooth_score=94,pothole_risk=5,groove_risk=5)
    g.add_edge("C","D",travel_minutes=6,smooth_score=94,pothole_risk=5,groove_risk=5)
    assert route(g,"A","D",BALANCED,"motorcycle") == ["A","C","D"]
