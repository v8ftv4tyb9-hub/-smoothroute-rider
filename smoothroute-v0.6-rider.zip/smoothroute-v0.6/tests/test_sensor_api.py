from fastapi.testclient import TestClient
from smoothroute.api import app


def test_collector_and_sensor_api(tmp_path, monkeypatch):
    monkeypatch.setenv('SMOOTHROUTE_SENSOR_DB', str(tmp_path/'api.db'))
    client=TestClient(app)
    assert client.get('/collector').status_code == 200
    trip=client.post('/v1/sensor/trips',json={'vehicle_label':'test'}).json()['trip_id']
    r=client.post(f'/v1/sensor/trips/{trip}/samples',json={'samples':[{
        'captured_at':'2026-01-01T00:00:00Z','lat':37.6,'lon':-122.3,
        'accuracy_m':5,'speed_mps':20,'ax':0.4,'ay':0.1,'az':0.2
    }]})
    assert r.status_code == 200 and r.json()['accepted']==1
    done=client.post(f'/v1/sensor/trips/{trip}/finish')
    assert done.status_code==200
    assert done.json()['analysis']['sample_count']==1


def test_trip_windows_csv_and_ios_assets(tmp_path, monkeypatch):
    monkeypatch.setenv('SMOOTHROUTE_SENSOR_DB', str(tmp_path/'api2.db'))
    client=TestClient(app)
    assert client.get('/manifest.webmanifest').status_code == 200
    assert client.get('/sw.js').status_code == 200
    html=client.get('/collector').text
    assert '1675 Pomona Ave, San Jose' in html
    assert 'Start recording' in html
    assert 'To Home' in html
    assert '1675 Pomona Ave, San Jose → Home/current location' in html
    trip=client.post('/v1/sensor/trips',json={'route_label':'Home/current location → 1675 Pomona Ave, San Jose','destination_label':'1675 Pomona Ave, San Jose'}).json()['trip_id']
    samples=[]
    for i in range(40):
        samples.append({'captured_at':f'2026-01-01T00:00:{i%60:02d}Z','lat':37.5+i*0.0001,'lon':-122.2,'accuracy_m':5,'speed_mps':20,'ax':0.6,'ay':0,'az':0})
    assert client.post(f'/v1/sensor/trips/{trip}/samples',json={'samples':samples}).status_code == 200
    done=client.post(f'/v1/sensor/trips/{trip}/finish').json()
    assert len(done['windows']) >= 3
    csv=client.get(f'/v1/sensor/trips/{trip}/windows.csv')
    assert csv.status_code == 200
    assert 'window_index' in csv.text


def test_motorcycle_profile_and_repeat_commute_summary(tmp_path, monkeypatch):
    monkeypatch.setenv('SMOOTHROUTE_SENSOR_DB', str(tmp_path/'repeat.db'))
    client=TestClient(app)
    route_label='Home/current location → 1675 Pomona Ave, San Jose'
    for pass_no in range(2):
        trip=client.post('/v1/sensor/trips',json={'route_label':route_label,'vehicle_profile':'motorcycle','vehicle_label':'motorcycle'}).json()['trip_id']
        samples=[]
        for i in range(60):
            samples.append({'captured_at':f'2026-01-0{pass_no+1}T00:00:{i%60:02d}Z','lat':37.5+i*0.00005,'lon':-122.2,'accuracy_m':5,'speed_mps':18,'ax':0.5+(pass_no*.03),'ay':0.1,'az':0.2})
        assert client.post(f'/v1/sensor/trips/{trip}/samples',json={'samples':samples}).status_code == 200
        done=client.post(f'/v1/sensor/trips/{trip}/finish').json()
        assert done['analysis']['vehicle_profile']=='motorcycle'
    summary=client.get('/v1/sensor/commute-summary',params={'route_label':route_label,'vehicle_profile':'motorcycle'}).json()
    assert summary['trip_count']==2
    assert summary['windows']
    assert summary['windows'][0]['passes']==2


def test_collector_defaults_to_motorcycle(tmp_path, monkeypatch):
    monkeypatch.setenv('SMOOTHROUTE_SENSOR_DB', str(tmp_path/'ui.db'))
    client=TestClient(app)
    html=client.get('/collector').text
    assert 'Vehicle profile' in html
    assert "vehicleProfile='motorcycle'" in html
    assert 'Scooter' in html
