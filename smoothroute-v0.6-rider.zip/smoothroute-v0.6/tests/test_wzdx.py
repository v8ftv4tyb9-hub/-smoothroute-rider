from smoothroute.providers.wzdx_511 import parse_wzdx


def test_parse_wzdx_linestring():
    payload={"type":"FeatureCollection","features":[{"type":"Feature","properties":{"road_event_id":"abc","event_status":"active","description":"US-101 paving"},"geometry":{"type":"LineString","coordinates":[[-122.4,37.7],[-122.3,37.8]]}}]}
    zones=parse_wzdx(payload)
    assert len(zones)==1
    assert zones[0].zone_id.startswith("abc")
    assert zones[0].severity >= 0.7
