from smoothroute.live_routing import build_pci_index, candidate_quality, normalize_road_name, select_routes
from smoothroute.models import PciRecord
from smoothroute.providers.osrm import RouteCandidate, RouteStep


def test_name_normalization():
    assert normalize_road_name("South First Street") == "SOUTH FIRST ST"
    assert normalize_road_name("El Camino Real") == "EL CAMINO REAL"


def test_public_pci_changes_route_choice():
    records = [
        PciRecord("test", "1", "US 101", 45),
        PciRecord("test", "2", "I 280", 95),
    ]
    idx = build_pci_index(records)
    fast = RouteCandidate(70000, 3000, {"type": "LineString", "coordinates": []}, (RouteStep("US 101", 70000, 3000),))
    smooth = RouteCandidate(74000, 3240, {"type": "LineString", "coordinates": []}, (RouteStep("I 280", 74000, 3240),))
    routes = select_routes([fast, smooth], idx)
    assert routes["fastest"]["travel_minutes"] == 50.0
    assert routes["smoothest"]["smooth_score"] > routes["fastest"]["smooth_score"]
    assert routes["smoothest"]["travel_minutes"] == 54.0


def test_unmatched_route_stays_neutral():
    c = RouteCandidate(1000, 100, {"type": "LineString", "coordinates": []}, (RouteStep("Mystery Rd", 1000, 100),))
    q = candidate_quality(c, {})
    assert q["smooth_score"] == 50.0
    assert q["pci_coverage_pct"] == 0.0
