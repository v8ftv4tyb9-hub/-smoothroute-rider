# SmoothRoute v0.5 — iPhone field run

## Tomorrow's run

Route labels: **Home/current location → 1675 Pomona Ave, San Jose** and **1675 Pomona Ave, San Jose → Home/current location**  
Primary measurement corridor: **US-101**  
Collector: `/collector`

The collector intentionally uses the phone's current GPS position as the origin instead of storing a home street address in source code.

## Before moving

1. Open the HTTPS SmoothRoute collector in Safari.
2. Optionally use Share → Add to Home Screen for an app-like launcher.
3. Secure the iPhone in a rigid mount. Keep the same orientation for the whole run.
4. Connect power if convenient.
5. Start your normal navigation app separately.
6. While still parked, return to SmoothRoute and tap **Start recording** once.
7. Approve Motion and Location if iPhone prompts for them.
8. Confirm GPS, Motion and Upload all change from their initial states.
9. Drive normally. Do not touch SmoothRoute while moving.
10. After reaching the destination and parking, tap **End trip**.

## What v0.5 records

- timestamp
- latitude/longitude and GPS accuracy
- GPS speed when available
- acceleration without gravity when Safari provides it
- rotation rate
- trip metadata and destination label

## Quality rules

v0.5 excludes samples from the roughness calculation when GPS accuracy is worse than 35 m, speed is below 4.5 m/s, motion is unavailable, or acceleration magnitude exceeds 25 m/s² (likely handling/mount artifact). It applies an experimental speed normalization before computing the roughness proxy.

## Post-drive output

The finished trip is divided into approximately **150 m distance windows**. Each window reports:

- center coordinate
- raw and usable sample count
- experimental sensor score
- roughness proxy
- impact count
- mean speed
- measurement-density confidence

A CSV can be downloaded directly from the trip-complete screen.

## Safety

Do not interact with the recorder while driving. Never deliberately strike a pothole, bump, shoulder, lane divider or road defect for measurement purposes. The goal is ordinary repeat driving.
