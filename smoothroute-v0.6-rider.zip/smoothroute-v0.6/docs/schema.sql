-- Production target: PostgreSQL + PostGIS
CREATE TABLE road_segments (
  segment_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  source_segment_id TEXT,
  road_name TEXT,
  direction TEXT,
  functional_class TEXT,
  geometry_wkt TEXT,
  freeflow_minutes DOUBLE PRECISION,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE road_quality_observations (
  observation_id BIGSERIAL PRIMARY KEY,
  segment_id TEXT REFERENCES road_segments(segment_id),
  observed_at TIMESTAMPTZ NOT NULL,
  source_type TEXT NOT NULL, -- municipal_pci, phone_sensor, pothole, construction
  pavement_score DOUBLE PRECISION,
  sensor_score DOUBLE PRECISION,
  defect_score DOUBLE PRECISION,
  construction_score DOUBLE PRECISION,
  confidence DOUBLE PRECISION NOT NULL,
  metadata JSONB
);

CREATE INDEX road_quality_segment_time_idx ON road_quality_observations(segment_id, observed_at DESC);

-- v0.4 prototype sensor collection tables. Production should use PostGIS geometry
-- and partition/high-throughput storage as trip volume grows.
CREATE TABLE sensor_trips (
  trip_id UUID PRIMARY KEY,
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  device_label TEXT,
  vehicle_label TEXT,
  notes TEXT
);

CREATE TABLE sensor_samples (
  sample_id BIGSERIAL PRIMARY KEY,
  trip_id UUID REFERENCES sensor_trips(trip_id),
  captured_at TIMESTAMPTZ NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  accuracy_m DOUBLE PRECISION,
  speed_mps DOUBLE PRECISION,
  accel_x DOUBLE PRECISION,
  accel_y DOUBLE PRECISION,
  accel_z DOUBLE PRECISION,
  gyro_x DOUBLE PRECISION,
  gyro_y DOUBLE PRECISION,
  gyro_z DOUBLE PRECISION,
  matched_segment_id TEXT REFERENCES road_segments(segment_id)
);
CREATE INDEX sensor_samples_trip_time_idx ON sensor_samples(trip_id, captured_at);
