import networkx as nx


def peninsula_demo_graph() -> nx.DiGraph:
    """Illustrative graph only. Real network ingestion is the next milestone."""
    g = nx.DiGraph()
    edges = [
        ("SF", "SSF", 12, 71, 12, 20, "US-101 S"),
        ("SSF", "SFO", 8, 66, 18, 35, "US-101 S"),
        ("SFO", "SM", 12, 74, 8, 25, "US-101 S"),
        ("SM", "RWC", 14, 68, 16, 30, "US-101 S"),
        ("RWC", "PA", 12, 82, 5, 15, "US-101 S"),
        ("PA", "MV", 8, 84, 4, 10, "US-101 S"),
        ("MV", "SJ", 15, 76, 10, 20, "US-101 S"),
        ("SF", "DC", 11, 88, 3, 5, "I-280 S"),
        ("DC", "SM280", 18, 92, 2, 5, "I-280 S"),
        ("SM280", "PA280", 24, 90, 2, 5, "I-280 S"),
        ("PA280", "SJ", 36, 91, 2, 5, "I-280 S"),
    ]
    for u, v, t, s, p, c, name in edges:
        g.add_edge(u, v, travel_minutes=t, smooth_score=s, pothole_risk=p, construction_risk=c, road_name=name)
    return g
