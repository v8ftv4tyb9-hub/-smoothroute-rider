from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import os
from typing import Annotated

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field

from .sensors import SensorSample, SensorStore, analyze_samples, aggregate_trip_windows, aggregate_repeat_trips, windows_csv

router = APIRouter(prefix="/v1/sensor", tags=["sensor"])


def _store() -> SensorStore:
    return SensorStore(Path(os.getenv("SMOOTHROUTE_SENSOR_DB", "smoothroute-sensors.db")))


class TripStart(BaseModel):
    device_label: str | None = None
    vehicle_label: str | None = None
    notes: str | None = None
    route_label: str | None = None
    destination_label: str | None = None
    vehicle_profile: str = "car"


class SampleIn(BaseModel):
    captured_at: datetime
    lat: Annotated[float, Field(ge=-90, le=90)]
    lon: Annotated[float, Field(ge=-180, le=180)]
    accuracy_m: float | None = Field(default=None, ge=0)
    speed_mps: float | None = Field(default=None, ge=0)
    ax: float | None = None
    ay: float | None = None
    az: float | None = None
    gx: float | None = None
    gy: float | None = None
    gz: float | None = None


class SampleBatch(BaseModel):
    samples: list[SampleIn] = Field(min_length=1, max_length=2000)


@router.post("/trips")
def start_trip(body: TripStart):
    return _store().start_trip(
        body.device_label, body.vehicle_label, body.notes, body.route_label, body.destination_label, body.vehicle_profile
    )


@router.post("/trips/{trip_id}/samples")
def ingest_samples(trip_id: str, body: SampleBatch):
    samples = [
        SensorSample(
            trip_id=trip_id,
            captured_at=(s.captured_at if s.captured_at.tzinfo else s.captured_at.replace(tzinfo=timezone.utc)),
            lat=s.lat, lon=s.lon, accuracy_m=s.accuracy_m, speed_mps=s.speed_mps,
            ax=s.ax, ay=s.ay, az=s.az, gx=s.gx, gy=s.gy, gz=s.gz,
        ) for s in body.samples
    ]
    try:
        count = _store().add_samples(trip_id, samples)
    except KeyError:
        raise HTTPException(404, "Unknown trip")
    return {"trip_id": trip_id, "accepted": count}


@router.post("/trips/{trip_id}/finish")
def finish_trip(trip_id: str):
    try:
        result = _store().finish_trip(trip_id)
        samples = _store().trip_samples(trip_id)
    except KeyError:
        raise HTTPException(404, "Unknown trip")
    meta = _store().trip_meta(trip_id)
    profile = meta.get("vehicle_profile") or "car"
    return {**result, "analysis": analyze_samples(samples, vehicle_profile=profile), "windows": aggregate_trip_windows(samples, vehicle_profile=profile)}


@router.get("/trips/{trip_id}")
def trip_summary(trip_id: str):
    try:
        meta = _store().trip_meta(trip_id)
        samples = _store().trip_samples(trip_id)
    except KeyError:
        raise HTTPException(404, "Unknown trip")
    bounds = None
    if samples:
        bounds = {"min_lat": min(s.lat for s in samples), "max_lat": max(s.lat for s in samples),
                  "min_lon": min(s.lon for s in samples), "max_lon": max(s.lon for s in samples)}
    profile = meta.get("vehicle_profile") or "car"
    return {"trip": meta, "bounds": bounds, "analysis": analyze_samples(samples, vehicle_profile=profile), "windows": aggregate_trip_windows(samples, vehicle_profile=profile)}


@router.get("/trips/{trip_id}/windows.csv", response_class=PlainTextResponse)
def trip_windows_csv(trip_id: str):
    try:
        samples = _store().trip_samples(trip_id)
        _store().trip_meta(trip_id)
    except KeyError:
        raise HTTPException(404, "Unknown trip")
    return PlainTextResponse(
        windows_csv(aggregate_trip_windows(samples, vehicle_profile=(_store().trip_meta(trip_id).get("vehicle_profile") or "car"))),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="smoothroute-{trip_id}-windows.csv"'},
    )


@router.get("/commute-summary")
def commute_summary(
    route_label: str = Query(min_length=1),
    vehicle_profile: str = Query(default="motorcycle"),
    window_m: float = Query(default=150.0, ge=50.0, le=500.0),
):
    store = _store()
    ids = store.matching_trip_ids(route_label, vehicle_profile)
    trips = [store.trip_samples(tid) for tid in ids]
    return {
        "route_label": route_label,
        "vehicle_profile": vehicle_profile.lower(),
        "trip_count": len(ids),
        "trip_ids": ids,
        "windows": aggregate_repeat_trips(trips, window_m=window_m, vehicle_profile=vehicle_profile),
    }
