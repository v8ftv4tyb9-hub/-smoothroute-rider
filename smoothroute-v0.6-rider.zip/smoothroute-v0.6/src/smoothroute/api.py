from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from .demo_graph import peninsula_demo_graph
from .models import FASTEST, BALANCED, SMOOTHEST
from .routing import route, summarize
from .live_routing import route_addresses
from .sensor_api import router as sensor_router
from pathlib import Path

app = FastAPI(title="SmoothRoute Bay Area Pilot", version="0.5.0")
app.include_router(sensor_router)
G = peninsula_demo_graph()
PREFS = {p.name: p for p in (FASTEST, BALANCED, SMOOTHEST)}


@app.get("/health")
def health():
    return {"status": "ok", "pilot": "SF-San Jose Peninsula", "version": "0.5.0"}


@app.get("/demo/routes")
def demo_routes(start: str = "SF", end: str = "SJ"):
    if start not in G or end not in G:
        raise HTTPException(404, "Unknown demo node")
    result = {}
    for name, pref in PREFS.items():
        path = route(G, start, end, pref)
        result[name] = summarize(G, path)
    return result


@app.get("/v1/routes")
def live_routes(
    origin: str = Query(..., description="Street address or place"),
    destination: str = Query(..., description="Street address or place"),
    include_pci: bool = True,
):
    try:
        return route_addresses(origin, destination, include_pci=include_pci)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f"Live routing dependency failed: {type(exc).__name__}: {exc}") from exc


@app.get("/collector", include_in_schema=False)
def collector():
    return FileResponse(Path(__file__).with_name("static") / "collector.html")

@app.get("/manifest.webmanifest", include_in_schema=False)
def manifest():
    return FileResponse(Path(__file__).with_name("static") / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js", include_in_schema=False)
def service_worker():
    return FileResponse(Path(__file__).with_name("static") / "sw.js", media_type="application/javascript", headers={"Service-Worker-Allowed": "/"})
