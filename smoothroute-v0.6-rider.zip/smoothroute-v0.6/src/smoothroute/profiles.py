from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class VehicleProfile:
    name: str
    roughness_multiplier: float
    pothole_multiplier: float
    construction_multiplier: float
    groove_multiplier: float
    metal_plate_multiplier: float
    seam_multiplier: float
    gravel_multiplier: float
    dip_multiplier: float
    impact_threshold_mps2: float
    min_analysis_speed_mps: float


CAR = VehicleProfile(
    "car", 1.00, 1.00, 1.00, 0.35, 0.35, 0.50, 0.45, 0.80, 4.0, 4.5
)
MOTORCYCLE = VehicleProfile(
    "motorcycle", 1.30, 1.65, 1.30, 1.60, 1.45, 1.35, 1.55, 1.45, 3.2, 3.0
)
SCOOTER = VehicleProfile(
    "scooter", 1.45, 1.90, 1.25, 1.55, 1.55, 1.55, 1.70, 1.70, 2.8, 2.0
)

PROFILES = {p.name: p for p in (CAR, MOTORCYCLE, SCOOTER)}


def get_vehicle_profile(name: str | None) -> VehicleProfile:
    if not name:
        return CAR
    return PROFILES.get(name.strip().lower(), CAR)
