from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import csv
import io
import math
import sqlite3
import statistics
import uuid
from pathlib import Path
from .profiles import get_vehicle_profile


EARTH_RADIUS_M = 6371008.8


@dataclass(frozen=True)
class SensorSample:
    trip_id: str
    captured_at: datetime
    lat: float
    lon: float
    accuracy_m: float | None
    speed_mps: float | None
    ax: float | None
    ay: float | None
    az: float | None
    gx: float | None = None
    gy: float | None = None
    gz: float | None = None

    @property
    def acceleration_magnitude(self) -> float | None:
        vals = (self.ax, self.ay, self.az)
        if any(v is None for v in vals):
            return None
        return math.sqrt(sum(float(v) ** 2 for v in vals))


class SensorStore:
    """Small SQLite persistence layer for prototype field collection."""

    def __init__(self, path: str | Path = "smoothroute-sensors.db") -> None:
        self.path = str(path)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS sensor_trips (
                  trip_id TEXT PRIMARY KEY,
                  started_at TEXT NOT NULL,
                  ended_at TEXT,
                  device_label TEXT,
                  vehicle_label TEXT,
                  notes TEXT,
                  route_label TEXT,
                  destination_label TEXT,
                  vehicle_profile TEXT DEFAULT 'car'
                );
                CREATE TABLE IF NOT EXISTS sensor_samples (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  trip_id TEXT NOT NULL,
                  captured_at TEXT NOT NULL,
                  lat REAL NOT NULL,
                  lon REAL NOT NULL,
                  accuracy_m REAL,
                  speed_mps REAL,
                  ax REAL,
                  ay REAL,
                  az REAL,
                  gx REAL,
                  gy REAL,
                  gz REAL,
                  road_segment_id TEXT,
                  FOREIGN KEY(trip_id) REFERENCES sensor_trips(trip_id)
                );
                CREATE INDEX IF NOT EXISTS sensor_samples_trip_time_idx
                  ON sensor_samples(trip_id, captured_at);
                CREATE INDEX IF NOT EXISTS sensor_samples_trip_geo_idx
                  ON sensor_samples(trip_id, lat, lon);
                """
            )
            # Safe migration for databases created by v0.4.
            cols = {r[1] for r in conn.execute("PRAGMA table_info(sensor_trips)").fetchall()}
            if "route_label" not in cols:
                conn.execute("ALTER TABLE sensor_trips ADD COLUMN route_label TEXT")
            if "destination_label" not in cols:
                conn.execute("ALTER TABLE sensor_trips ADD COLUMN destination_label TEXT")
            if "vehicle_profile" not in cols:
                conn.execute("ALTER TABLE sensor_trips ADD COLUMN vehicle_profile TEXT DEFAULT 'car'")

    def start_trip(
        self,
        device_label: str | None = None,
        vehicle_label: str | None = None,
        notes: str | None = None,
        route_label: str | None = None,
        destination_label: str | None = None,
        vehicle_profile: str | None = None,
    ) -> dict:
        trip_id = str(uuid.uuid4())
        started_at = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO sensor_trips(
                trip_id, started_at, device_label, vehicle_label, notes, route_label, destination_label, vehicle_profile
                ) VALUES (?,?,?,?,?,?,?,?)""",
                (trip_id, started_at, device_label, vehicle_label, notes, route_label, destination_label, (vehicle_profile or "car").lower()),
            )
        return {"trip_id": trip_id, "started_at": started_at}

    def add_samples(self, trip_id: str, samples: list[SensorSample]) -> int:
        if not samples:
            return 0
        with self._connect() as conn:
            exists = conn.execute("SELECT 1 FROM sensor_trips WHERE trip_id=?", (trip_id,)).fetchone()
            if not exists:
                raise KeyError(trip_id)
            conn.executemany(
                """
                INSERT INTO sensor_samples(
                  trip_id,captured_at,lat,lon,accuracy_m,speed_mps,ax,ay,az,gx,gy,gz
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                [
                    (
                        s.trip_id,
                        s.captured_at.astimezone(timezone.utc).isoformat(),
                        s.lat,
                        s.lon,
                        s.accuracy_m,
                        s.speed_mps,
                        s.ax,
                        s.ay,
                        s.az,
                        s.gx,
                        s.gy,
                        s.gz,
                    )
                    for s in samples
                ],
            )
        return len(samples)

    def finish_trip(self, trip_id: str) -> dict:
        ended_at = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cur = conn.execute("UPDATE sensor_trips SET ended_at=? WHERE trip_id=?", (ended_at, trip_id))
            if cur.rowcount == 0:
                raise KeyError(trip_id)
        return {"trip_id": trip_id, "ended_at": ended_at}

    def trip_samples(self, trip_id: str) -> list[SensorSample]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM sensor_samples WHERE trip_id=? ORDER BY captured_at", (trip_id,)
            ).fetchall()
        return [
            SensorSample(
                trip_id=r["trip_id"], captured_at=datetime.fromisoformat(r["captured_at"]),
                lat=r["lat"], lon=r["lon"], accuracy_m=r["accuracy_m"], speed_mps=r["speed_mps"],
                ax=r["ax"], ay=r["ay"], az=r["az"], gx=r["gx"], gy=r["gy"], gz=r["gz"],
            )
            for r in rows
        ]


    def matching_trip_ids(self, route_label: str, vehicle_profile: str | None = None) -> list[str]:
        with self._connect() as conn:
            if vehicle_profile:
                rows = conn.execute(
                    "SELECT trip_id FROM sensor_trips WHERE route_label=? AND lower(coalesce(vehicle_profile,'car'))=? AND ended_at IS NOT NULL ORDER BY started_at",
                    (route_label, vehicle_profile.lower()),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT trip_id FROM sensor_trips WHERE route_label=? AND ended_at IS NOT NULL ORDER BY started_at",
                    (route_label,),
                ).fetchall()
        return [r["trip_id"] for r in rows]

    def trip_meta(self, trip_id: str) -> dict:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM sensor_trips WHERE trip_id=?", (trip_id,)).fetchone()
        if not row:
            raise KeyError(trip_id)
        return dict(row)


def haversine_m(a: SensorSample, b: SensorSample) -> float:
    lat1, lat2 = math.radians(a.lat), math.radians(b.lat)
    dlat = lat2 - lat1
    dlon = math.radians(b.lon - a.lon)
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2 * EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(h)))


def _quality_filter(samples: list[SensorSample], vehicle_profile: str = "car") -> tuple[list[SensorSample], dict]:
    """Reject observations likely to be poor road measurements.

    v0.5 rules are deliberately simple: poor GPS, very low speed, impossible sensor
    spikes and missing acceleration are excluded from roughness calculations.
    """
    profile = get_vehicle_profile(vehicle_profile)
    accepted: list[SensorSample] = []
    rejected = {"gps": 0, "low_speed": 0, "motion_missing": 0, "handling_spike": 0}
    for s in samples:
        if s.accuracy_m is not None and s.accuracy_m > 35:
            rejected["gps"] += 1
            continue
        if s.speed_mps is not None and s.speed_mps < profile.min_analysis_speed_mps:
            rejected["low_speed"] += 1
            continue
        mag = s.acceleration_magnitude
        if mag is None or not math.isfinite(mag):
            rejected["motion_missing"] += 1
            continue
        if mag > 25:
            rejected["handling_spike"] += 1
            continue
        accepted.append(s)
    return accepted, rejected


def analyze_samples(samples: list[SensorSample], impact_threshold_mps2: float | None = None, vehicle_profile: str = "car") -> dict:
    """Return an intentionally conservative, uncalibrated ride-roughness proxy.

    This is not IRI and should not be presented as a pavement engineering measurement.
    v0.5 adds quality rejection and a modest speed normalization so repeated passes are
    more comparable, but calibration against reference drives remains necessary.
    """
    profile = get_vehicle_profile(vehicle_profile)
    if impact_threshold_mps2 is None:
        impact_threshold_mps2 = profile.impact_threshold_mps2
    good, rejected = _quality_filter(samples, vehicle_profile)
    mags = [s.acceleration_magnitude for s in good]
    mags = [float(m) for m in mags if m is not None and math.isfinite(m)]
    speeds = [s.speed_mps for s in good if s.speed_mps is not None and s.speed_mps >= 0]
    if not mags:
        return {
            "sample_count": len(samples), "usable_sample_count": 0, "motion_sample_count": 0,
            "roughness_proxy": None, "sensor_score": None, "impact_count": 0,
            "mean_speed_mps": round(statistics.fmean(speeds), 2) if speeds else None,
            "rejected": rejected,
        }

    normalized = []
    for s in good:
        m = s.acceleration_magnitude
        if m is None:
            continue
        # Normalize to roughly 20 m/s (~45 mph). Faster travel naturally excites more
        # vertical motion; sqrt scaling avoids over-correcting. Experimental only.
        if s.speed_mps is None or s.speed_mps <= 0:
            scale = 1.0
        else:
            scale = max(0.70, min(1.50, math.sqrt(s.speed_mps / 20.0)))
        normalized.append(m / scale)

    rms = math.sqrt(sum(m * m for m in normalized) / len(normalized))
    p95 = sorted(normalized)[max(0, math.ceil(0.95 * len(normalized)) - 1)]
    impact_count = sum(1 for m in normalized if m >= impact_threshold_mps2)
    impact_rate = impact_count / len(normalized)
    proxy = rms + 2.0 * impact_rate
    sensor_score = max(0.0, min(100.0, 100.0 - proxy * 12.0))

    return {
        "sample_count": len(samples), "usable_sample_count": len(good), "motion_sample_count": len(mags),
        "roughness_proxy": round(proxy, 4), "sensor_score": round(sensor_score, 1),
        "accel_rms_mps2": round(rms, 4), "accel_p95_mps2": round(p95, 4),
        "impact_count": impact_count, "impact_rate_pct": round(impact_rate * 100.0, 2),
        "mean_speed_mps": round(statistics.fmean(speeds), 2) if speeds else None,
        "rejected": rejected,
        "vehicle_profile": profile.name,
    }


def aggregate_trip_windows(samples: list[SensorSample], window_m: float = 150.0, vehicle_profile: str = "car") -> list[dict]:
    """Aggregate a trip into distance-based windows for post-drive pavement review."""
    if not samples:
        return []
    windows: list[list[SensorSample]] = [[]]
    distances = [0.0]
    cumulative = 0.0
    prev = samples[0]
    for s in samples:
        if s is not samples[0]:
            step = haversine_m(prev, s)
            # Ignore GPS teleportation while preserving the observation for its local window.
            if step < 500:
                cumulative += step
            prev = s
        idx = int(cumulative // window_m)
        while len(windows) <= idx:
            windows.append([])
        windows[idx].append(s)
        distances.append(cumulative)

    out = []
    for idx, group in enumerate(windows):
        if not group:
            continue
        analysis = analyze_samples(group, vehicle_profile=vehicle_profile)
        usable = analysis.get("usable_sample_count", 0)
        # Confidence is about measurement density only; repeat-trip agreement will be
        # added once multiple trips cover the same spatial segment.
        density_conf = min(1.0, usable / 25.0)
        out.append({
            "window_index": idx,
            "start_m": round(idx * window_m, 1),
            "end_m": round((idx + 1) * window_m, 1),
            "center_lat": round(statistics.fmean(s.lat for s in group), 7),
            "center_lon": round(statistics.fmean(s.lon for s in group), 7),
            "samples": len(group),
            "usable_samples": usable,
            "sensor_score": analysis.get("sensor_score"),
            "roughness_proxy": analysis.get("roughness_proxy"),
            "impact_count": analysis.get("impact_count", 0),
            "mean_speed_mps": analysis.get("mean_speed_mps"),
            "confidence": round(density_conf, 2),
        })
    return out


def aggregate_repeat_trips(trips: list[list[SensorSample]], window_m: float = 150.0, vehicle_profile: str = "motorcycle") -> list[dict]:
    """Combine repeat runs of the same directional commute by window index.

    This v0.6 prototype assumes broadly consistent routing. Confidence rises with
    repeat coverage and falls when independent passes disagree substantially.
    """
    by_index: dict[int, list[dict]] = {}
    for samples in trips:
        for row in aggregate_trip_windows(samples, window_m=window_m, vehicle_profile=vehicle_profile):
            if row.get("sensor_score") is not None:
                by_index.setdefault(int(row["window_index"]), []).append(row)
    out=[]
    for idx in sorted(by_index):
        rows=by_index[idx]
        scores=[float(r["sensor_score"]) for r in rows]
        median=statistics.median(scores)
        spread=statistics.pstdev(scores) if len(scores)>1 else 20.0
        repeat_factor=min(1.0, len(rows)/5.0)
        agreement=max(0.0, 1.0-min(spread,25.0)/25.0)
        confidence=repeat_factor*(0.45+0.55*agreement)
        out.append({
            "window_index": idx, "start_m": round(idx*window_m,1), "end_m": round((idx+1)*window_m,1),
            "passes": len(rows), "median_sensor_score": round(median,1), "score_spread": round(spread,1),
            "confidence": round(confidence,2),
            "center_lat": round(statistics.fmean(float(r["center_lat"]) for r in rows),7),
            "center_lon": round(statistics.fmean(float(r["center_lon"]) for r in rows),7),
            "vehicle_profile": get_vehicle_profile(vehicle_profile).name,
        })
    return out


def windows_csv(windows: list[dict]) -> str:
    buf = io.StringIO()
    fields = ["window_index", "start_m", "end_m", "center_lat", "center_lon", "samples", "usable_samples", "sensor_score", "roughness_proxy", "impact_count", "mean_speed_mps", "confidence"]
    w = csv.DictWriter(buf, fieldnames=fields)
    w.writeheader()
    for row in windows:
        w.writerow({k: row.get(k) for k in fields})
    return buf.getvalue()


def match_samples_to_pci_segments(samples, pci_segments, max_distance_m: float = 35.0) -> list[dict]:
    from .spatial import point_polyline_distance_m
    out = []
    for s in samples:
        point = (s.lon, s.lat)
        best = None
        best_d = None
        for seg in pci_segments:
            d = point_polyline_distance_m(point, seg.geometry)
            if best_d is None or d < best_d:
                best, best_d = seg, d
        matched = best is not None and best_d is not None and best_d <= max_distance_m
        out.append({
            "sample": s, "segment_id": best.segment_id if matched else None,
            "source": best.source if matched else None,
            "street_name": best.street_name if matched else None,
            "distance_m": round(best_d, 2) if matched else None,
        })
    return out
