from __future__ import annotations
import os
import httpx
from ..models import ConstructionZone

WZDX_URL = "https://api.511.org/traffic/wzdx"


def _first(mapping: dict, *keys, default=None):
    for k in keys:
        if k in mapping and mapping[k] is not None:
            return mapping[k]
    return default


def _severity(props: dict) -> float:
    # Conservative defaults: closures receive the strongest penalty; otherwise
    # work zones still receive a meaningful but non-blocking cost.
    text = str(_first(props, "event_status", "type", "event_type", "description", default="")).lower()
    if "closed" in text or "closure" in text:
        return 1.0
    if "active" in text or "work" in text or "construction" in text:
        return 0.7
    return 0.5


def parse_wzdx(payload: dict) -> list[ConstructionZone]:
    zones: list[ConstructionZone] = []
    features = payload.get("features") or []
    for i, feature in enumerate(features):
        props = feature.get("properties") or {}
        core = props.get("core_details") if isinstance(props.get("core_details"), dict) else {}
        merged = {**props, **core}
        geom = feature.get("geometry") or {}
        coords = geom.get("coordinates") or []
        if geom.get("type") == "MultiLineString":
            lines = coords
        elif geom.get("type") == "LineString":
            lines = [coords]
        else:
            continue
        zid = str(_first(merged, "road_event_id", "id", default=f"wzdx:{i}"))
        description = _first(merged, "description", "road_name", "name")
        for n, line in enumerate(lines):
            parsed = tuple((float(x), float(y)) for x, y, *_ in line) if line else ()
            if len(parsed) >= 2:
                zones.append(ConstructionZone(f"{zid}:{n}", parsed, _severity(merged), str(description) if description else None))
    return zones


def fetch_511_work_zones(api_key: str | None = None, client: httpx.Client | None = None) -> list[ConstructionZone]:
    api_key = api_key or os.getenv("SMOOTHROUTE_511_API_KEY")
    if not api_key:
        return []
    owns = client is None
    client = client or httpx.Client(timeout=30)
    try:
        response = client.get(WZDX_URL, params={"api_key": api_key})
        response.raise_for_status()
        return parse_wzdx(response.json())
    finally:
        if owns:
            client.close()
