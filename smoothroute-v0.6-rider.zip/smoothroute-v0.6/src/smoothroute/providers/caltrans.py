from __future__ import annotations
import httpx

CALTRANS_D4_CLOSURES = "https://cwwp2.dot.ca.gov/data/d4/lcs/lcsStatusD04.json"


def fetch_d4_closures():
    return httpx.get(CALTRANS_D4_CLOSURES, timeout=30).raise_for_status().json()
