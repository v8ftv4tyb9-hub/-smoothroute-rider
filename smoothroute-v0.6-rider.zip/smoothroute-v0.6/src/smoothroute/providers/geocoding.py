from __future__ import annotations
from dataclasses import dataclass
import httpx

NOMINATIM_SEARCH = "https://nominatim.openstreetmap.org/search"
USER_AGENT = "SmoothRoute-Peninsula-Pilot/0.2"


@dataclass(frozen=True)
class Location:
    label: str
    lat: float
    lon: float


def geocode(query: str, client: httpx.Client | None = None) -> Location:
    owns_client = client is None
    client = client or httpx.Client(timeout=20, headers={"User-Agent": USER_AGENT})
    try:
        response = client.get(NOMINATIM_SEARCH, params={"q": query, "format": "jsonv2", "limit": 1, "countrycodes": "us"})
        response.raise_for_status()
        rows = response.json()
    finally:
        if owns_client:
            client.close()
    if not rows:
        raise ValueError(f"Could not geocode address: {query}")
    row = rows[0]
    return Location(row.get("display_name", query), float(row["lat"]), float(row["lon"]))
