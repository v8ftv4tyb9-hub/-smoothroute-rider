from __future__ import annotations
from datetime import datetime, timezone
import httpx
from ..models import PciRecord, PciSegment

SJ_PCI_QUERY_URL = "https://geo.sanjoseca.gov/server/rest/services/OPN/OPN_OpenDataService/MapServer/502/query"


def _esri_dt(value) -> datetime | None:
    if value is None: return None
    return datetime.fromtimestamp(float(value) / 1000.0, tz=timezone.utc)


def _fetch(page_size: int, return_geometry: bool, client: httpx.Client) -> list[dict]:
    out=[]; offset=0
    while True:
        params={"f":"geojson" if return_geometry else "json","where":"PCICURRENT IS NOT NULL","outFields":"OBJECTID,STREETNAME,STREETFROM,STREETTO,PCICURRENT,PCIDATE,LASTUPDATE","returnGeometry":"true" if return_geometry else "false","outSR":"4326","resultOffset":str(offset),"resultRecordCount":str(page_size),"orderByFields":"OBJECTID"}
        response=client.get(SJ_PCI_QUERY_URL,params=params); response.raise_for_status(); payload=response.json()
        if "error" in payload: raise RuntimeError(f"San Jose ArcGIS error: {payload['error']}")
        features=payload.get("features",[]); out.extend(features)
        if len(features)<page_size or not payload.get("exceededTransferLimit",False): break
        offset += len(features)
    return out


def fetch_sj_pci(page_size: int = 2000, client: httpx.Client | None = None) -> list[PciRecord]:
    owns=client is None; client=client or httpx.Client(timeout=30)
    try: features=_fetch(page_size,False,client)
    finally:
        if owns: client.close()
    out=[]
    for f in features:
        a=f.get("attributes",{}); name=a.get("STREETNAME"); pci=a.get("PCICURRENT")
        if name and pci is not None:
            out.append(PciRecord("sj",f"sj:{a.get('OBJECTID')}",name,float(pci),a.get("STREETFROM"),a.get("STREETTO"),_esri_dt(a.get("LASTUPDATE")) or _esri_dt(a.get("PCIDATE"))))
    return out


def fetch_sj_pci_segments(page_size: int = 2000, client: httpx.Client | None = None) -> list[PciSegment]:
    owns=client is None; client=client or httpx.Client(timeout=45)
    try: features=_fetch(page_size,True,client)
    finally:
        if owns: client.close()
    out=[]
    for f in features:
        # GeoJSON uses properties; JSON fallback may use attributes.
        a=f.get("properties") or f.get("attributes",{}); g=f.get("geometry") or {}
        name=a.get("STREETNAME"); pci=a.get("PCICURRENT")
        coords=g.get("coordinates") or []
        if g.get("type") == "MultiLineString": coords=max(coords,key=len,default=[])
        line=tuple((float(x),float(y)) for x,y,*_ in coords) if coords else ()
        if name and pci is not None and line:
            out.append(PciSegment("sj",f"sj:{a.get('OBJECTID')}",name,float(pci),line,_esri_dt(a.get("LASTUPDATE")) or _esri_dt(a.get("PCIDATE"))))
    return out
