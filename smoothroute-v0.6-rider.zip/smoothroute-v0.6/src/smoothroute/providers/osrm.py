from __future__ import annotations
from dataclasses import dataclass
import httpx
from .geocoding import Location

OSRM_ROUTE = "https://router.project-osrm.org/route/v1/driving"


@dataclass(frozen=True)
class RouteStep:
    name: str
    distance_m: float
    duration_s: float


@dataclass(frozen=True)
class RouteCandidate:
    distance_m: float
    duration_s: float
    geometry: dict
    steps: tuple[RouteStep, ...]


def fetch_route_candidates(origin: Location, destination: Location, alternatives: int = 3,
                           client: httpx.Client | None = None) -> list[RouteCandidate]:
    coords = f"{origin.lon},{origin.lat};{destination.lon},{destination.lat}"
    url = f"{OSRM_ROUTE}/{coords}"
    owns_client = client is None
    client = client or httpx.Client(timeout=30)
    try:
        response = client.get(url, params={
            "alternatives": str(alternatives),
            "steps": "true",
            "overview": "full",
            "geometries": "geojson",
        })
        response.raise_for_status()
        payload = response.json()
    finally:
        if owns_client:
            client.close()
    if payload.get("code") != "Ok":
        raise RuntimeError(f"Routing provider error: {payload.get('message', payload.get('code'))}")

    candidates = []
    for route in payload.get("routes", []):
        steps = []
        for leg in route.get("legs", []):
            for s in leg.get("steps", []):
                steps.append(RouteStep(s.get("name") or "Unnamed road", float(s.get("distance", 0)), float(s.get("duration", 0))))
        candidates.append(RouteCandidate(
            distance_m=float(route.get("distance", 0)),
            duration_s=float(route.get("duration", 0)),
            geometry=route.get("geometry") or {"type": "LineString", "coordinates": []},
            steps=tuple(steps),
        ))
    return candidates
