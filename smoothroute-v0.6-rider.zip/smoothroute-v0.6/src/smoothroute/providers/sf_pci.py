from __future__ import annotations
from datetime import datetime
import re
import httpx
from ..models import PciRecord, PciSegment

SF_PCI_URL = "https://data.sfgov.org/resource/5aye-4rtt.json"
SF_STREETS_URL = "https://data.sfgov.org/resource/3psu-pn9h.json"


def _dt(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value) if value else None


def _parse_linestring(value: str | None) -> tuple[tuple[float, float], ...]:
    if not value:
        return ()
    m = re.search(r"LINESTRING\s*\((.*)\)", value, re.I)
    if not m:
        return ()
    pts = []
    for pair in m.group(1).split(','):
        x, y = pair.strip().split()[:2]
        pts.append((float(x), float(y)))
    return tuple(pts)


def fetch_sf_pci(limit: int = 50000, client: httpx.Client | None = None) -> list[PciRecord]:
    params = {"$limit": str(limit), "$select": "cnn,street_name,pci_score,pci_change_date,from_street,to_street", "$where": "pci_score is not null"}
    owns_client = client is None
    client = client or httpx.Client(timeout=30)
    try:
        response = client.get(SF_PCI_URL, params=params); response.raise_for_status(); rows = response.json()
    finally:
        if owns_client: client.close()
    return [PciRecord("sf", f"sf:{row['cnn']}", row.get("street_name", ""), float(row["pci_score"]), row.get("from_street"), row.get("to_street"), _dt(row.get("pci_change_date"))) for row in rows if row.get("street_name") and row.get("pci_score") is not None]


def fetch_sf_pci_segments(limit: int = 50000, client: httpx.Client | None = None) -> list[PciSegment]:
    """Join official PCI rows to official SF street-centerline geometry using CNN."""
    owns_client = client is None
    client = client or httpx.Client(timeout=45)
    try:
        pci = fetch_sf_pci(limit=limit, client=client)
        response = client.get(SF_STREETS_URL, params={"$limit": str(limit), "$select": "cnn,street,st_type,the_geom", "$where": "active=true"})
        response.raise_for_status(); rows = response.json()
    finally:
        if owns_client: client.close()
    geom = {}
    for r in rows:
        raw = r.get("the_geom")
        if isinstance(raw, dict):
            coords = raw.get("coordinates") or []
            line = tuple((float(x), float(y)) for x, y, *_ in coords)
        else:
            line = _parse_linestring(raw)
        if line:
            geom[str(r.get("cnn"))] = line
    out = []
    for r in pci:
        cnn = r.segment_id.split(':', 1)[1]
        line = geom.get(cnn)
        if line:
            out.append(PciSegment(r.source, r.segment_id, r.street_name, r.pavement_score, line, r.updated_at))
    return out
