from __future__ import annotations
import networkx as nx
from .models import RoutePreference
from .profiles import get_vehicle_profile


def edge_cost(data: dict, pref: RoutePreference, vehicle_profile: str = "car") -> float:
    """Generalized route cost with two-wheel-specific surface hazard penalties.

    Hazard fields are expected as 0-100 risks. Missing fields are neutral (zero risk),
    allowing the model to grow as new detection sources become available.
    """
    profile = get_vehicle_profile(vehicle_profile)
    minutes = float(data.get("travel_minutes", 1.0))
    smooth = float(data.get("smooth_score", 50.0))
    roughness = (100.0 - smooth) / 100.0

    def risk(name: str) -> float:
        return max(0.0, min(1.0, float(data.get(name, 0.0)) / 100.0))

    multiplier = (
        1.0
        + pref.roughness_weight * profile.roughness_multiplier * roughness
        + pref.defect_weight * profile.pothole_multiplier * risk("pothole_risk")
        + pref.construction_weight * profile.construction_multiplier * risk("construction_risk")
        + pref.groove_weight * profile.groove_multiplier * risk("groove_risk")
        + pref.metal_plate_weight * profile.metal_plate_multiplier * risk("metal_plate_risk")
        + pref.seam_weight * profile.seam_multiplier * risk("seam_risk")
        + pref.gravel_weight * profile.gravel_multiplier * risk("gravel_risk")
        + pref.dip_weight * profile.dip_multiplier * risk("dip_risk")
    )
    return minutes * multiplier


def route(graph: nx.DiGraph, start: str, end: str, pref: RoutePreference, vehicle_profile: str = "car") -> list[str]:
    return nx.shortest_path(
        graph,
        source=start,
        target=end,
        weight=lambda u, v, d: edge_cost(d, pref, vehicle_profile),
    )


def summarize(graph: nx.DiGraph, path: list[str]) -> dict:
    edges = [graph[u][v] for u, v in zip(path[:-1], path[1:])]
    minutes = sum(float(e.get("travel_minutes", 0)) for e in edges)
    weighted_smooth = sum(float(e.get("smooth_score", 50)) * float(e.get("travel_minutes", 0)) for e in edges)
    smooth = weighted_smooth / minutes if minutes else 50.0
    hazards = {
        name: round(max((float(e.get(name, 0.0)) for e in edges), default=0.0), 1)
        for name in ("pothole_risk", "construction_risk", "groove_risk", "metal_plate_risk", "seam_risk", "gravel_risk", "dip_risk")
    }
    return {"path": path, "travel_minutes": round(minutes, 1), "smooth_score": round(smooth, 1), "hazards": hazards}
