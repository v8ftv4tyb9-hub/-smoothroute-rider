from __future__ import annotations
from dataclasses import dataclass
from math import cos, radians, sqrt
from .models import PciSegment

EARTH_M_PER_DEG_LAT = 111_320.0


def _xy_m(lon: float, lat: float, ref_lat: float) -> tuple[float, float]:
    return lon * EARTH_M_PER_DEG_LAT * cos(radians(ref_lat)), lat * EARTH_M_PER_DEG_LAT


def distance_m(a: tuple[float, float], b: tuple[float, float]) -> float:
    ref = (a[1] + b[1]) / 2.0
    ax, ay = _xy_m(a[0], a[1], ref)
    bx, by = _xy_m(b[0], b[1], ref)
    return sqrt((ax - bx) ** 2 + (ay - by) ** 2)


def point_segment_distance_m(p: tuple[float, float], a: tuple[float, float], b: tuple[float, float]) -> float:
    ref = p[1]
    px, py = _xy_m(p[0], p[1], ref)
    ax, ay = _xy_m(a[0], a[1], ref)
    bx, by = _xy_m(b[0], b[1], ref)
    dx, dy = bx - ax, by - ay
    if dx == 0 and dy == 0:
        return sqrt((px - ax) ** 2 + (py - ay) ** 2)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
    qx, qy = ax + t * dx, ay + t * dy
    return sqrt((px - qx) ** 2 + (py - qy) ** 2)


def point_polyline_distance_m(p: tuple[float, float], coords: tuple[tuple[float, float], ...]) -> float:
    if not coords:
        return float("inf")
    if len(coords) == 1:
        return distance_m(p, coords[0])
    return min(point_segment_distance_m(p, a, b) for a, b in zip(coords, coords[1:]))


def interpolate(a: tuple[float, float], b: tuple[float, float], fraction: float) -> tuple[float, float]:
    return (a[0] + (b[0] - a[0]) * fraction, a[1] + (b[1] - a[1]) * fraction)


def route_windows(coords: list[list[float]] | tuple, window_m: float = 150.0) -> list[dict]:
    """Resample a LineString into length-weighted windows with midpoint coordinates."""
    pts = [(float(c[0]), float(c[1])) for c in coords]
    if len(pts) < 2:
        return []
    out: list[dict] = []
    carry = 0.0
    window_start = pts[0]
    accumulated = 0.0
    current = pts[0]
    for target in pts[1:]:
        seg_start = current
        seg_len = distance_m(seg_start, target)
        remaining = seg_len
        while remaining > 1e-6:
            need = window_m - accumulated
            if remaining >= need:
                frac = need / remaining
                cut = interpolate(seg_start, target, frac)
                mid = interpolate(window_start, cut, 0.5)
                out.append({"start": window_start, "end": cut, "midpoint": mid, "length_m": window_m})
                window_start = cut
                seg_start = cut
                remaining -= need
                accumulated = 0.0
            else:
                accumulated += remaining
                remaining = 0.0
        current = target
    if accumulated > 1.0:
        mid = interpolate(window_start, pts[-1], 0.5)
        out.append({"start": window_start, "end": pts[-1], "midpoint": mid, "length_m": accumulated})
    return out


def match_windows_to_pci(
    coords: list[list[float]] | tuple,
    segments: list[PciSegment],
    window_m: float = 150.0,
    max_distance_m: float = 65.0,
) -> list[dict]:
    windows = route_windows(coords, window_m=window_m)
    for w in windows:
        best = None
        best_d = float("inf")
        for segment in segments:
            d = point_polyline_distance_m(w["midpoint"], segment.geometry)
            if d < best_d:
                best, best_d = segment, d
        if best is not None and best_d <= max_distance_m:
            w["segment_id"] = best.segment_id
            w["source"] = best.source
            w["street_name"] = best.street_name
            w["pci"] = best.pavement_score
            w["match_distance_m"] = round(best_d, 1)
        else:
            w["segment_id"] = None
            w["source"] = None
            w["street_name"] = None
            w["pci"] = None
            w["match_distance_m"] = None
    return windows
