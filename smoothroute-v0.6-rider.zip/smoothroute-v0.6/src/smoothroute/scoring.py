from __future__ import annotations
from datetime import datetime, timezone
from .models import RoadQuality


def _bounded(v: float) -> float:
    return max(0.0, min(100.0, v))


def recency_factor(updated_at: datetime | None, half_life_days: float = 365.0) -> float:
    if updated_at is None:
        return 0.35
    if updated_at.tzinfo is None:
        updated_at = updated_at.replace(tzinfo=timezone.utc)
    age_days = max(0.0, (datetime.now(timezone.utc) - updated_at).total_seconds() / 86400)
    return 0.5 ** (age_days / half_life_days)


def smooth_score(q: RoadQuality) -> float:
    """V0.1 fused road score. 100 = smooth/clear, 0 = poor/obstructed."""
    components: list[tuple[float, float]] = []
    if q.pavement_score is not None:
        components.append((_bounded(q.pavement_score), 0.45))
    if q.sensor_score is not None:
        components.append((_bounded(q.sensor_score), 0.30))
    if q.defect_score is not None:
        components.append((_bounded(q.defect_score), 0.15))
    if q.construction_score is not None:
        components.append((_bounded(q.construction_score), 0.10))
    if not components:
        return 50.0
    total_w = sum(w for _, w in components)
    base = sum(v * w for v, w in components) / total_w
    freshness = recency_factor(q.updated_at)
    confidence = _bounded(q.confidence) / 100.0
    # Pull weak/stale observations toward neutral rather than pretending certainty.
    trust = 0.25 + 0.50 * confidence + 0.25 * freshness
    return round(50.0 + (base - 50.0) * trust, 1)
