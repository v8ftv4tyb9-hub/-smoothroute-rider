from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class RoadQuality:
    segment_id: str
    pavement_score: float | None = None
    sensor_score: float | None = None
    defect_score: float | None = None
    construction_score: float | None = None
    confidence: float = 0.0
    updated_at: datetime | None = None


@dataclass(frozen=True)
class PciRecord:
    source: str
    segment_id: str
    street_name: str
    pavement_score: float
    from_street: str | None = None
    to_street: str | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True)
class PciSegment:
    source: str
    segment_id: str
    street_name: str
    pavement_score: float
    geometry: tuple[tuple[float, float], ...]
    updated_at: datetime | None = None


@dataclass(frozen=True)
class ConstructionZone:
    zone_id: str
    geometry: tuple[tuple[float, float], ...]
    severity: float = 1.0
    description: str | None = None


@dataclass(frozen=True)
class RoutePreference:
    name: str
    roughness_weight: float
    defect_weight: float
    construction_weight: float
    groove_weight: float = 0.0
    metal_plate_weight: float = 0.0
    seam_weight: float = 0.0
    gravel_weight: float = 0.0
    dip_weight: float = 0.0


FASTEST = RoutePreference("fastest", 0.00, 0.00, 0.00)
BALANCED = RoutePreference("balanced", 0.35, 0.20, 0.15, 0.10, 0.10, 0.08, 0.10, 0.10)
SMOOTHEST = RoutePreference("smoothest", 0.85, 0.50, 0.35, 0.30, 0.30, 0.25, 0.30, 0.30)
