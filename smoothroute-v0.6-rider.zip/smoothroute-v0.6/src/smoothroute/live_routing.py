from __future__ import annotations
from collections import defaultdict
import re
from .models import PciRecord, PciSegment, ConstructionZone, RoutePreference, FASTEST, BALANCED, SMOOTHEST
from .providers.geocoding import geocode
from .providers.osrm import RouteCandidate, fetch_route_candidates
from .providers.sf_pci import fetch_sf_pci, fetch_sf_pci_segments
from .providers.sj_pci import fetch_sj_pci, fetch_sj_pci_segments
from .providers.wzdx_511 import fetch_511_work_zones
from .spatial import match_windows_to_pci, point_polyline_distance_m

PREFS = (FASTEST, BALANCED, SMOOTHEST)


def normalize_road_name(name: str) -> str:
    value = name.upper().strip()
    aliases = {"STREET":"ST","AVENUE":"AVE","BOULEVARD":"BLVD","ROAD":"RD","DRIVE":"DR","HIGHWAY":"HWY","EXPRESSWAY":"EXPY","PARKWAY":"PKWY"}
    value = re.sub(r"[^A-Z0-9 ]+", " ", value)
    return " ".join(aliases.get(p,p) for p in value.split())


def build_pci_index(records: list[PciRecord]) -> dict[str, float]:
    grouped: dict[str, list[float]] = defaultdict(list)
    for r in records:
        key = normalize_road_name(r.street_name)
        if key: grouped[key].append(r.pavement_score)
    return {k: sum(v)/len(v) for k,v in grouped.items()}


def _construction_overlap(windows: list[dict], zones: list[ConstructionZone], max_distance_m: float = 75.0) -> tuple[float, int]:
    if not windows or not zones: return 0.0, 0
    affected_m = 0.0; hits = 0; severity_m = 0.0
    total_m = sum(w["length_m"] for w in windows)
    for w in windows:
        best = None
        for z in zones:
            d = point_polyline_distance_m(w["midpoint"], z.geometry)
            if d <= max_distance_m and (best is None or z.severity > best.severity): best = z
        if best:
            hits += 1; affected_m += w["length_m"]; severity_m += w["length_m"] * max(0.0, min(1.0, best.severity))
    return (severity_m / total_m if total_m else 0.0), hits


def candidate_quality_spatial(candidate: RouteCandidate, segments: list[PciSegment], construction_zones: list[ConstructionZone] | None = None, window_m: float = 150.0) -> dict:
    coords = (candidate.geometry or {}).get("coordinates") or []
    windows = match_windows_to_pci(coords, segments, window_m=window_m)
    total_m = sum(w["length_m"] for w in windows)
    matched = [w for w in windows if w["pci"] is not None]
    matched_m = sum(w["length_m"] for w in matched)
    measured = (sum(w["pci"] * w["length_m"] for w in matched) / matched_m) if matched_m else 50.0
    coverage = matched_m / total_m if total_m else 0.0
    smooth = measured * coverage + 50.0 * (1.0 - coverage)
    construction_fraction, construction_hits = _construction_overlap(windows, construction_zones or [])
    # A construction overlay affects route cost independently; SmoothScore remains a pavement score.
    return {
        "smooth_score": round(smooth, 1),
        "pci_coverage_pct": round(coverage * 100.0, 1),
        "pci_matched_windows": len(matched),
        "scoring_windows": len(windows),
        "window_m": window_m,
        "confidence": round(min(100.0, coverage * 100.0), 1),
        "construction_fraction": round(construction_fraction, 4),
        "construction_windows": construction_hits,
        "segments": [
            {
                "start": [round(w["start"][1], 6), round(w["start"][0], 6)],
                "end": [round(w["end"][1], 6), round(w["end"][0], 6)],
                "length_m": round(w["length_m"], 1),
                "pci": None if w["pci"] is None else round(w["pci"], 1),
                "segment_id": w["segment_id"],
                "street_name": w["street_name"],
                "source": w["source"],
                "match_distance_m": w["match_distance_m"],
            } for w in windows
        ],
    }


def candidate_quality(candidate: RouteCandidate, pci_index: dict[str, float]) -> dict:
    """v0.2 compatibility path used by the offline tests and as a live fallback."""
    matched_seconds=score_seconds=0.0; matched_steps=0
    total_seconds=sum(s.duration_s for s in candidate.steps)
    for step in candidate.steps:
        pci=pci_index.get(normalize_road_name(step.name))
        if pci is None: continue
        matched_steps += 1; matched_seconds += step.duration_s; score_seconds += pci * step.duration_s
    coverage=matched_seconds/total_seconds if total_seconds else 0.0
    measured=score_seconds/matched_seconds if matched_seconds else 50.0
    smooth=measured*coverage+50.0*(1.0-coverage)
    return {"smooth_score":round(smooth,1),"pci_coverage_pct":round(coverage*100,1),"pci_matched_steps":matched_steps,"confidence":round(min(100.0,coverage*100),1),"construction_fraction":0.0}


def preference_cost(candidate: RouteCandidate, quality: dict, pref: RoutePreference) -> float:
    minutes=candidate.duration_s/60.0
    roughness=(100.0-quality["smooth_score"])/100.0
    construction=float(quality.get("construction_fraction",0.0))
    return minutes*(1.0 + pref.roughness_weight*roughness + pref.construction_weight*construction)


def select_routes(candidates: list[RouteCandidate], pci_index: dict[str,float] | None = None, pci_segments: list[PciSegment] | None = None, construction_zones: list[ConstructionZone] | None = None) -> dict:
    if pci_segments:
        enriched=[(c,candidate_quality_spatial(c,pci_segments,construction_zones)) for c in candidates]
        method="spatial"
    else:
        enriched=[(c,candidate_quality(c,pci_index or {})) for c in candidates]
        method="street_name_fallback"
    result={}
    for pref in PREFS:
        if not enriched: raise ValueError("Routing provider returned no candidate routes")
        chosen,q=min(enriched,key=lambda item:preference_cost(item[0],item[1],pref))
        result[pref.name]={"travel_minutes":round(chosen.duration_s/60,1),"distance_miles":round(chosen.distance_m/1609.344,1),"scoring_method":method,**q,"geometry":chosen.geometry,"roads":[s.name for s in chosen.steps if s.name and s.name!="Unnamed road"][:40]}
    return result


def route_addresses(origin_query: str, destination_query: str, include_pci: bool = True) -> dict:
    origin=geocode(origin_query); destination=geocode(destination_query)
    candidates=fetch_route_candidates(origin,destination)
    records: list[PciRecord]=[]; segments: list[PciSegment]=[]; warnings=[]
    if include_pci:
        for source, seg_loader, fallback_loader in (
            ("San Francisco PCI", fetch_sf_pci_segments, fetch_sf_pci),
            ("San Jose PCI", fetch_sj_pci_segments, fetch_sj_pci),
        ):
            try:
                city_segments=seg_loader(); segments.extend(city_segments)
            except Exception as exc:
                warnings.append(f"{source} geometry unavailable: {type(exc).__name__}")
                try: records.extend(fallback_loader())
                except Exception as fallback_exc: warnings.append(f"{source} fallback unavailable: {type(fallback_exc).__name__}")
    construction_zones=[]
    try:
        construction_zones=fetch_511_work_zones()
    except Exception as exc:
        warnings.append(f"511 WZDx unavailable: {type(exc).__name__}")
    routes=select_routes(candidates, build_pci_index(records), segments, construction_zones)
    return {
        "origin":{"query":origin_query,"label":origin.label,"lat":origin.lat,"lon":origin.lon},
        "destination":{"query":destination_query,"label":destination.label,"lat":destination.lat,"lon":destination.lon},
        "public_pci_segments":len(segments),
        "public_pci_fallback_records":len(records),
        "construction_zones":len(construction_zones),
        "warnings":warnings,
        "routes":routes,
    }
