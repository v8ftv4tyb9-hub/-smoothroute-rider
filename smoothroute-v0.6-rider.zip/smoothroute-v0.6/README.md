# SmoothRoute v0.6 — iPhone US-101 field pilot

SmoothRoute explores navigation that trades a small amount of travel time for better pavement and fewer construction/rough-road penalties.

## What v0.5 adds

- iPhone-first field collector at `/collector`
- preconfigured field-test route picker for **Home/current location ↔ 1675 Pomona Ave, San Jose**
- privacy-friendly **Home** label in both directions (the home street address is not embedded in source)
- Home Screen web-app manifest and service worker
- one-tap Motion + Location permission flow
- Screen Wake Lock request when supported by Safari
- automatic upload batching and live GPS/motion/upload status
- quality rejection for poor GPS, low speed, missing motion and extreme handling spikes
- experimental speed normalization
- automatic ~150 m post-drive windows
- per-window score, impact count, sample density and confidence
- downloadable window CSV

The v0.3 spatial PCI routing, 511 work-zone logic and v0.4 sensor persistence remain intact.

## Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
uvicorn smoothroute.api:app --host 0.0.0.0 --port 8000
```

For an iPhone field test, expose the service using **HTTPS**. Open `/collector` in Safari. A secure context is required for the motion/location experience we rely on.

## Sensor API

- `POST /v1/sensor/trips`
- `POST /v1/sensor/trips/{trip_id}/samples`
- `POST /v1/sensor/trips/{trip_id}/finish`
- `GET /v1/sensor/trips/{trip_id}`
- `GET /v1/sensor/trips/{trip_id}/windows.csv`
- `GET /collector`

Set `SMOOTHROUTE_SENSOR_DB=/path/to/file.db` to choose the SQLite database.

## Measurement caveat

The v0.5 sensor score is experimental. It is **not IRI or PCI** and is not yet normalized for all vehicle, tire, suspension, mount, device, lane or traffic effects. v0.5 is for repeatability testing and data collection.

See `docs/field_test.md` for the iPhone field protocol.

## Deployment for iPhone testing

A `Dockerfile` is included. Deploy the container to any HTTPS-capable host with a persistent volume mounted at `/data` if you want sensor data to survive container restarts. After deployment, open:

`https://YOUR-HOST/collector`

in Safari on the iPhone. Optionally use Share → Add to Home Screen.


## v0.6 — two-wheel phase

- Motorcycle, Scooter and Car sensor profiles. Motorcycle is the field-test default.
- Two-wheel route-cost penalties for potholes, grooves, metal plates, seams, gravel and dips.
- Vehicle-specific sensor filtering/impact thresholds. These remain experimental and are not PCI/IRI.
- `GET /v1/sensor/commute-summary` aggregates repeat directional commute passes into 150 m windows using median sensor score, pass count, score spread and repeat confidence.
- The iPhone collector lets the rider select Motorcycle/Scooter/Car while parked and stores the profile with each trip.

The current repeat-window aggregation assumes broadly consistent routing between passes. A later build will spatially align repeat windows rather than relying primarily on distance-from-trip-start.
